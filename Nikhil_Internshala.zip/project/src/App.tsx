import React, { useState, useEffect } from 'react';
import { LoginForm } from './components/LoginForm';
import { TaskList } from './components/TaskList';
import { TaskForm } from './components/TaskForm';
import { Header } from './components/Header';
import { FilterTabs } from './components/FilterTabs';
import { SearchBar } from './components/SearchBar';
import { Task, User, FilterType } from './types';
import { loadTasks, saveTasks, loadUser, saveUser, clearUser } from './utils/storage';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [filter, setFilter] = useState<FilterType>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  useEffect(() => {
    const savedUser = loadUser();
    if (savedUser) {
      setUser(savedUser);
      const userTasks = loadTasks(savedUser.email);
      setTasks(userTasks);
    }
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    saveUser(userData);
    const userTasks = loadTasks(userData.email);
    setTasks(userTasks);
  };

  const handleLogout = () => {
    setUser(null);
    setTasks([]);
    clearUser();
  };

  const handleAddTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    if (!user) return;
    
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    
    const updatedTasks = [...tasks, newTask];
    setTasks(updatedTasks);
    saveTasks(user.email, updatedTasks);
    setShowTaskForm(false);
  };

  const handleEditTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    if (!user || !editingTask) return;
    
    const updatedTask: Task = {
      ...editingTask,
      ...taskData,
    };
    
    const updatedTasks = tasks.map(task => 
      task.id === editingTask.id ? updatedTask : task
    );
    
    setTasks(updatedTasks);
    saveTasks(user.email, updatedTasks);
    setEditingTask(null);
  };

  const handleDeleteTask = (taskId: string) => {
    if (!user) return;
    
    const updatedTasks = tasks.filter(task => task.id !== taskId);
    setTasks(updatedTasks);
    saveTasks(user.email, updatedTasks);
  };

  const handleToggleComplete = (taskId: string) => {
    if (!user) return;
    
    const updatedTasks = tasks.map(task =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );
    
    setTasks(updatedTasks);
    saveTasks(user.email, updatedTasks);
  };

  const filteredTasks = tasks.filter(task => {
    const matchesFilter = 
      filter === 'all' ||
      (filter === 'pending' && !task.completed) ||
      (filter === 'completed' && task.completed);
    
    const matchesSearch = 
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header user={user} onLogout={handleLogout} />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              Welcome back, {user.name}! 👋
            </h1>
            <p className="text-gray-600">
              You have {tasks.filter(t => !t.completed).length} pending tasks
            </p>
          </div>

          <div className="mb-6 flex flex-col sm:flex-row gap-4 items-center justify-between">
            <FilterTabs currentFilter={filter} onFilterChange={setFilter} />
            <SearchBar value={searchTerm} onChange={setSearchTerm} />
          </div>

          <div className="mb-6">
            <button
              onClick={() => setShowTaskForm(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add New Task
            </button>
          </div>

          <TaskList
            tasks={filteredTasks}
            onEdit={setEditingTask}
            onDelete={handleDeleteTask}
            onToggleComplete={handleToggleComplete}
          />

          {(showTaskForm || editingTask) && (
            <TaskForm
              task={editingTask}
              onSubmit={editingTask ? handleEditTask : handleAddTask}
              onCancel={() => {
                setShowTaskForm(false);
                setEditingTask(null);
              }}
            />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;