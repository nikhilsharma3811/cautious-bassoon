import { Task, User } from '../types';

const USER_KEY = 'task-tracker-user';
const TASKS_KEY_PREFIX = 'task-tracker-tasks-';

export const saveUser = (user: User): void => {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const loadUser = (): User | null => {
  const userData = localStorage.getItem(USER_KEY);
  return userData ? JSON.parse(userData) : null;
};

export const clearUser = (): void => {
  localStorage.removeItem(USER_KEY);
};

export const saveTasks = (userEmail: string, tasks: Task[]): void => {
  const key = TASKS_KEY_PREFIX + userEmail;
  localStorage.setItem(key, JSON.stringify(tasks));
};

export const loadTasks = (userEmail: string): Task[] => {
  const key = TASKS_KEY_PREFIX + userEmail;
  const tasksData = localStorage.getItem(key);
  return tasksData ? JSON.parse(tasksData) : [];
};