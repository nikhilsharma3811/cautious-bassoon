export interface User {
  name: string;
  email: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  dueDate: string;
  completed: boolean;
  createdAt: string;
}

export type FilterType = 'all' | 'pending' | 'completed';